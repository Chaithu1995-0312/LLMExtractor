# Canonical DB Migration Runbook

This runbook defines a practical, ordered way to initialize and migrate Nexus databases from a clean environment.

It is based on current repository entry points and schema files.

---

## 1) Database topology

Nexus currently has **two data stores**:

1. **Primary operational DB (PostgreSQL)**
   - Driven by `DATABASE_URL`
   - Holds `sync`, `graph`, `governance`, and extension schemas (`graph_ai`, `graph_sandbox`, `cognition`, `audit`)

2. **Memory Layer DB (SQLite)**
   - File: `data/memory_layer.db`
   - Owned by `src/nexus/memory/_db.py`
   - Tables: `memory_datasets`, `memory_chunks`

---

## 2) Canonical migration sequence (PostgreSQL)

Run in this order for a fresh environment.

### Phase A — Baseline schema

1. **Initialize core baseline**
   - Entry point: `python src/nexus/db/init_db.py`
   - Applies: `src/nexus/graph/schema_postgres.sql`
   - Creates baseline schemas/tables:
     - `sync.*` (topics, source_runs, bricks, cognitive_shards)
     - `graph.nodes`, `graph.edges`
     - `governance.*` (prompts, coverage alerts, attempts, audit_trace)

### Phase B — Core feature schema packs

2. **Intent schema**
   - `python src/nexus/scripts/apply_intent_schema.py`
   - Adds `graph.intent_metrics`; creates `GIN` index on `graph.nodes(data)`

3. **Cognition schema (v1 + v2)**
   - `python scripts/apply_cognition_schema.py`
   - `python scripts/apply_cognition_schema_v2.py`
   - Adds `graph.cognition_logs`, `graph.cognition_budget`, `graph.cognition_calibration`, and log extensions

4. **Cognitive compiler schema**
   - `python scripts/apply_cognitive_compiler_schema.py`
   - Ensures `cognition` schema and creates compiler/governance tables

5. **Pulse schema**
   - `python scripts/apply_pulse_schema.py`
   - Creates `graph.pulse_events`

6. **L3 task queue + clustering**
   - `python scripts/apply_l3_schema.py`
   - `python scripts/apply_l3_clustering_schema.py`
   - Creates `graph.l3_tasks`, `graph.cluster_runs`, `graph.node_clusters`, and cluster stats shape

7. **Evolution schema (choose one track carefully)**
   - Newer comprehensive: `python scripts/apply_evolution_schema.py` (recommended)
   - Older/legacy variant: `python scripts/apply_evolution_schema_fixed.py`

### Phase C — Targeted incremental migrations

8. **Vector unification**
   - Apply: `scripts/migrations/001_vector_unification.sql`
   - Adds `graph.vector_meta.embedding_v2`, `embedding_model_v2`

9. **Decision cache**
   - Apply: `scripts/migrations/002_decision_cache.sql`
   - Creates `graph.decision_cache`

10. **Goal engine**
    - Apply: `scripts/migrations/003_goal_engine.sql`
    - Creates `graph.goals`

11. **Status tracking (modern)**
    - `python scripts/apply_migration_cloud.py`
    - Applies `schema_status_tracking.sql`
    - Adds `cognitive_status` enum and status lifecycle columns to `graph.nodes` and `sync.bricks`

12. **Audit tables + trigger**
    - `python scripts/migrations/20240628_audit_tables.py`
    - Apply SQL: `scripts/migrations/20240629_audit_triggers.sql`
    - Creates `audit.processing_trail`, `audit.alerts`, and anomaly trigger

### Phase D — Data migrations / post-schema jobs

13. **Vector data backfill**
    - `python scripts/run_vector_migration.py`
    - Populates `graph.vector_meta.embedding_v2`; marks vector status fields in `graph.nodes`

14. **Refresh evolution metrics (if V2 enabled)**
    - SQL: `SELECT graph.refresh_metrics();`

---

## 3) Dependency graph (high level)

`init_db.py` → baseline (`sync`, `graph`, `governance`)  
Feature scripts (`intent`, `cognition`, `compiler`, `pulse`, `l3`, `evolution`) depend on baseline  
Targeted migrations (`001/002/003`, audit, status-tracking) depend on relevant tables/schemas existing  
Data migrations (`run_vector_migration.py`) depend on both schema and model/API availability

---

## 4) Known overlap/conflict notes

1. **`graph.cluster_stats` appears in multiple schema tracks**
   - Defined in `schema_evolution.sql`
   - Also managed/recreated in `schema_l3_clustering.sql`
   - Recommendation: standardize one canonical shape and update all readers/writers accordingly.

2. **Status columns have legacy + modern paths**
   - Legacy: `scripts/migrations/20240625_status_columns.py` (older SQLAlchemy-style script)
   - Modern: `schema_status_tracking.sql` via `apply_migration_cloud.py`
   - Recommendation: prefer modern path; treat legacy as historical.

3. **Evolution V1 vs V2 coexistence**
   - `schema_evolution.sql` and `schema_evolution_v2.sql` both present
   - Recommendation: prefer V2 in new environments and document any required compatibility layer.

4. **SQLite schema files are still present for local/testing flows**
   - `schema_sync.sql`, `scripts/update_db.py`
   - Recommendation: keep explicitly labeled as local/test legacy unless actively used in production flow.

---

## 5) Operational verification checklist

After migrations, verify quickly:

1. Core schemas exist:
   - `sync`, `graph`, `governance`, and optionally `cognition`, `graph_ai`, `graph_sandbox`, `audit`

2. Baseline tables exist:
   - `sync.topics`, `sync.source_runs`, `sync.bricks`
   - `graph.nodes`, `graph.edges`

3. Optional feature tables exist per enabled module:
   - cognition: `graph.cognition_logs`, `graph.cognition_budget`, `graph.cognition_calibration`, `cognition.*`
   - evolution: `graph.concept_versions`, `graph_ai.*`, `graph_sandbox.*`
   - vector: `graph.vector_meta`, `graph.decision_cache`
   - ops/audit: `audit.processing_trail`, `audit.alerts`

4. Background data jobs complete without DDL errors:
   - `scripts/run_vector_migration.py`

---

## 6) Memory Layer (SQLite) runbook

Memory DB bootstrap is automatic through:

- `src/nexus/memory/_db.py`
  - `get_memory_db_path()`
  - `ensure_memory_schema(db_path)`

Expected artifacts:

- File: `data/memory_layer.db`
- Tables: `memory_datasets`, `memory_chunks`
- Chroma directory: `data/memory_chroma/`

---

## 7) Suggested “new environment” minimal command order

```bash
python src/nexus/db/init_db.py
python src/nexus/scripts/apply_intent_schema.py
python scripts/apply_cognition_schema.py
python scripts/apply_cognition_schema_v2.py
python scripts/apply_cognitive_compiler_schema.py
python scripts/apply_pulse_schema.py
python scripts/apply_l3_schema.py
python scripts/apply_l3_clustering_schema.py
python scripts/apply_evolution_schema.py
python scripts/migrations/20240628_audit_tables.py
python scripts/run_vector_migration.py
```

Then apply any additional targeted SQL migrations required by your deployment profile (`001/002/003`, audit triggers, status tracking).
